const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const HASH_PATTERNS = [
  { name: 'MD5', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'MD4', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'MD2', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'SHA1', regex: /^[a-f0-9]{40}$/i, bits: 160 },
  { name: 'SHA224', regex: /^[a-f0-9]{56}$/i, bits: 224 },
  { name: 'SHA256', regex: /^[a-f0-9]{64}$/i, bits: 256 },
  { name: 'SHA384', regex: /^[a-f0-9]{96}$/i, bits: 384 },
  { name: 'SHA512', regex: /^[a-f0-9]{128}$/i, bits: 512 },
  { name: 'SHA3-224', regex: /^[a-f0-9]{56}$/i, bits: 224 },
  { name: 'SHA3-256', regex: /^[a-f0-9]{64}$/i, bits: 256 },
  { name: 'SHA3-384', regex: /^[a-f0-9]{96}$/i, bits: 384 },
  { name: 'SHA3-512', regex: /^[a-f0-9]{128}$/i, bits: 512 },
  { name: 'RIPEMD-160', regex: /^[a-f0-9]{40}$/i, bits: 160 },
  { name: 'Whirlpool', regex: /^[a-f0-9]{128}$/i, bits: 512 },
  { name: 'MySQL5', regex: /^[a-f0-9]{40}$/i, bits: 160 },
  { name: 'MySQL4.1', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'MD5(APR)', regex: /^\$apr1\$.+\$.{22}$/ },
  { name: 'SHA512(Unix)', regex: /^\$6\$.+\$.{86}$/ },
  { name: 'SHA256(Unix)', regex: /^\$5\$.+\$.{43}$/ },
  { name: 'Bcrypt', regex: /^\$2[ayb]\$.+\$.{53}$/ },
  { name: 'MD5(Sun)', regex: /^\$md5\$.+\$.{22}$/ },
  { name: 'NTLM', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'LM', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'CRC32', regex: /^[a-f0-9]{8}$/i, bits: 32 },
  { name: 'Adler32', regex: /^[a-f0-9]{8}$/i, bits: 32 },
  { name: 'GOST R 34.11-94', regex: /^[a-f0-9]{64}$/i, bits: 256 },
  { name: 'Skype', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'MD5(strtoupper(MD5))', regex: /^[a-f0-9]{32}$/i, bits: 128 },
  { name: 'MD5(WordPress)', regex: /^\$P\$.{31}$/ },
  { name: 'MD5(phpBB3)', regex: /^\$H\$.{31}$/ },
  { name: 'SHA256(Django)', regex: /^sha256\$.{32}\$.{64}$/ },
  { name: 'PBKDF2-HMAC-SHA256', regex: /^pbkdf2_sha256\$.+\$.+\$.+$/ },
  { name: 'Double SHA1', regex: /^[a-f0-9]{40}$/i, bits: 160 },
];

class HashIdentifier {
  identify(hash) {
    if (!hash || typeof hash !== 'string') {
      return { success: false, error: 'No hash provided' };
    }
    const h = hash.trim();
    const results = HASH_PATTERNS.filter(p => p.regex.test(h));
    const unique = [];
    const seen = new Set();
    for (const r of results) {
      const key = r.name;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push({ name: r.name, bits: r.bits || null });
      }
    }
    const length = h.length;
    const charset = /^[a-f0-9]+$/i.test(h) ? 'hex' :
                    /^[A-Za-z0-9+/]+={0,2}$/.test(h) ? 'base64' :
                    /^\$/.test(h) ? 'crypt' : 'unknown';
    return {
      success: true,
      hash: h,
      length,
      charset,
      possibleTypes: unique,
      count: unique.length
    };
  }

  async crackWithWordlist(hash, wordlistPath) {
    try {
      const resolved = this.identify(hash);
      if (!resolved.success) return resolved;
      const types = resolved.possibleTypes;
      const hashLower = hash.toLowerCase();
      const wordlist = wordlistPath || path.join(__dirname, '..', 'wordlist.txt');
      if (!fs.existsSync(wordlist)) {
        return { ...resolved, cracked: false, reason: 'Wordlist not found' };
      }
      const data = fs.readFileSync(wordlist, 'utf8');
      const words = data.split('\n').filter(w => w.trim());
      let found = null;
      for (const word of words) {
        const w = word.trim();
        if (!w) continue;
        for (const t of types) {
          const algo = t.name.split('(')[0].split('-')[0].replace(/\s+/g, '');
          let computed;
          try {
            if (t.name === 'MD5' || t.name === 'MD4' || t.name === 'MD2') {
              computed = crypto.createHash('md5').update(w).digest('hex');
            } else if (t.name.startsWith('SHA1') || t.name === 'MySQL5') {
              computed = crypto.createHash('sha1').update(w).digest('hex');
            } else if (t.name === 'SHA224') {
              computed = crypto.createHash('sha224').update(w).digest('hex');
            } else if (t.name === 'SHA256' || t.name === 'SHA3-256') {
              computed = crypto.createHash('sha256').update(w).digest('hex');
            } else if (t.name === 'SHA384') {
              computed = crypto.createHash('sha384').update(w).digest('hex');
            } else if (t.name === 'SHA512' || t.name === 'Whirlpool') {
              computed = crypto.createHash('sha512').update(w).digest('hex');
            } else if (t.name === 'NTLM') {
              computed = crypto.createHash('md4').update(Buffer.from(w, 'utf16le')).digest('hex');
            } else if (t.name === 'LM') {
              computed = crypto.createHash('md4').update(w.slice(0, 14).toUpperCase()).digest('hex');
            } else {
              computed = crypto.createHash('md5').update(w).digest('hex');
            }
            if (computed.toLowerCase() === hashLower) {
              found = w;
              break;
            }
          } catch { continue; }
        }
        if (found) break;
      }
      return { ...resolved, cracked: !!found, password: found };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = new HashIdentifier();
